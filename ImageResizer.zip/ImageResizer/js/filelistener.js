let pattern = /\.jpeg|jpg|png|gif|webp$/g;

$(document).ready(function(){
  $(".input_file").change(function(){
    let pathArray=$(this).val().split('\\');
    let file = pathArray[pathArray.length-1];
    let result = file.match(pattern);
    if(result != null){
    $(".input_file-button").removeClass("error");
    $(".input_file-button-text").text("Выбран файл:"+file);
    }
    else {
      $(".input_file-button-text").text("Неверный формат файла!");
      $(".input_file-button").addClass("error");
    }
  });
});
