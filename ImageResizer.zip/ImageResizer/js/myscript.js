let inputFile = document.querySelector('.input_file');
let pattern = /\.jpeg|jpg|png|gif|webp$/g

inputFile.onchange = function(e){
  let display = document.querySelector('.input_file-button-text');
  let val =this.value.split('\\');
  let file=val[val.length-1];
  let result = file.match(pattern);
  if(result != null) {
    display.innerText='Выбран файл:'+file;
    if(document.querySelector(".error") != null){
      document.querySelector(".error").classList.remove('error');
    };
    }
  else {
    display.innerText='Неверный формат файла';
    document.querySelector('.input_file-button').classList.add('error');
  }
}
