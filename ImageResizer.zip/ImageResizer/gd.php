<?php
echo "<pre>";
var_dump(gd_info());
echo "</pre>";
?>
