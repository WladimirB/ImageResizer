<?php

class Router{
  static private $routes;

  private function __construct(){}
  private function __clone(){}

  private static function getUri()
  {
    if(!empty($_SERVER['REQUEST_URI'])) {
    return trim($_SERVER['REQUEST_URI'],'/');
    }
  }

  public static function run(){
    $uri=self::getUri();
    if(empty(self::$routes)){
      self::$routes=include_once('./app/config/routes.php');
    }

    foreach (self::$routes as $uriPattern => $path) {
      if(preg_match("~$uriPattern~", $uri)) {
        $request = preg_replace("~$uriPattern~",$path,$uri);
        $settings =  explode('/', $request);
        $controllerName = 'Controller'.ucfirst($settings[0]);
        $controllerFile = ROOT.'/app/controllers/'.lcfirst($controllerName).'.php';
        if(file_exists($controllerFile)){
          include_once($controllerFile);
        }
        else
        {
          echo 'not found';
        }
        $params=array();
        $action='action'.ucfirst($settings[1]);
        if(count($settings)>2){
          $params=array_slice($settings,2);
        }
        //$controller=new $controllerName($params);
        $debug=array($controllerName,$controllerFile,$action,$request);
        $controller=new $controllerName();
        call_user_func_array(array($controller,$action),$params);
        break;
      }
    }

  }

}
