
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="/css/main.css">
    <title>Virtual1</title>
    <script src="/js/jquery.js"></script>
  </head>
  <body>
    <header class="container">
      <h1 class="site-header">Сайт редактирования картинок и фото</h1>
      <nav class="navbar">
        <ul>
          <li>
            <a href="/about.php">О сайте</a>
          </li>
          <li>
            <a href="#">Вход|Регистрация</a>
          </li>
        </ul>
      </nav>
    </header>
  <main class="container">
    <div class="row">
      <article class="col col__article">
        <form class="image-form"  method="post">
          <label for="imgwidth">Ширина</label>
          <input type="number" name="imgwidth" id="imgwidth" placeholder="введите
          ширину изображения (в px)">
          <label for="imgheight">Высота</label>
          <input type="number" name="imgheight" id="imgheight" placeholder="введите
          высоту изображения (в px)">
          <div class="input_wrapper">
            <input type="file" name="file" id="input_file" class="input_file">
            <label for="input_file" class="input_file-button">
              <span class="input_file-icon-wrapper">
                <img class="input_file-icon" src="/img/download.png" alt="icon">
              </span>
              <span class="input_file-button-text">Выберите файл</span>
            </label>
          </div>
          <input type="submit" name="submit" value="Готово">
        </form>
      </article>
      <aside class="col col__aside">
        <p>Боковая панель</p>
        <?php
        if(isset($_POST)){
          foreach ($_POST as $key => $value) {
            echo '<span>'.$key. ':'.$value.'</span></br>';
          }
        }
        ?>
      </aside>
    </div>
  </main>
  <footer class="container">
    <p>&copy;Все права защищены</p>
    <p>Спасибо что выбрали нас</p>
  </footer>
  <script src="/js/filelistener.js"></script>
  </body>
</html>
