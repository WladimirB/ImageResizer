<?php
include 'controllerSite.php';

class ControllerRegister extends ControllerSite{
  public function actionIndex()
  {
    echo $this->view->render('register.tpl');
  }
}
