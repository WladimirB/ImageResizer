<?php
class ControllerGd {
  private $view;

  public function __construct(){
    $loader = new Twig_Loader_Filesystem('./views/');
    $twig = new Twig_Environment($loader);
    $this->view=$twig;
  }

  public function actionIndex(){
    $gd = gd_info();
    echo $this->view->render('gd.tpl',array('info'=>$gd));
  }

}
