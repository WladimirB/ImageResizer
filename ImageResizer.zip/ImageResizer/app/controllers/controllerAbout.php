<?php
class ControllerAbout {
  private $view;

  public function __construct(){
    $loader = new Twig_Loader_Filesystem('./views/');
    $twig = new Twig_Environment($loader);
    $this->view=$twig;
  }

  public function actionIndex(){
    echo $this->view->render('about.tpl');
  }

}
