<?php
include ROOT.'/app/core/imageHandler.php';

 class ControllerSite {
   protected $view;
   private $imageHandler;

   public function __construct(array $args=null){
     $loader = new Twig_Loader_Filesystem('./views/');
     $twig = new Twig_Environment($loader);
     $this->view=$twig;
   }

   public function actionIndex(){
     echo $this->view->render('main.tpl',array('post'=>$_POST));
   }

   public function actionHandler(){
   if(!empty($_POST['imgwidth']) && !empty($_POST['imgheight']) && !empty($_FILES['file']['name'])) {
       $sizes = $this->valid();
       $file = $this->checkFile();
       if($file && $sizes) {
       list($w,$h)=array_values($sizes);
       $this->imageHandler = new ImageHandler($file,$w,$h,'./resize');
       $result = $this->imageHandler->getInfo();
       $result['img']=$this->imageHandler->getImage();
       }
       else {
         $result['результат']='Некорретные данные,невозможно обработать';
       }
       echo $this->view->render('main.tpl',array('post'=>$result));
     }
     else {
       echo $this->view->render('main.tpl',array('response'=>'ничего не отправлено'));
     }
   }

  private function checkFile(){
    $file=$_FILES['file']['tmp_name'];
    if(is_uploaded_file($file)){
      if(mime_content_type($file)=='image/jpeg' || 'image/png' || 'image/svg')
      {
      //$upload=ROOT.'/upload';
      //$newfile=$_FILES['file']['name'];
      //move_uploaded_file($file,"$upload/$newfile");
      //$file=$upload."/".$newfile;
      return $file;
      }
    }
    else {
      return false;
    }
  }

  private function valid() {
    $rules=[
      'imgwidth' => '/(^\d{2,4})$/s',
      'imgheight' => '/(^\d{2,4})$/s'
    ];
    $formData=array_intersect_key($_POST,$rules);

    foreach ($rules as $key => $value) {
      preg_match($value,$formData[$key],$matches);
      if(!$matches){
        $resultValid=false;
        break;
      }
      else{
        $resultValid=$formData;
      }
    }
    return $resultValid;
  }

 }
