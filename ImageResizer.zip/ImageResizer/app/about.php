<?php

include './vendor/autoload.php';

$loader = new Twig_Loader_Filesystem('./views/');
$twig = new Twig_Environment($loader);

//$template = $twig->loadTemplate('h.html');

echo $twig->render('about.tpl');

?>
