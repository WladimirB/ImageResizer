<?php
return array(
'index/handler'=>'site/handler/',
'about'=>'about/index/',
'index'=>'site/index/',
'register'=>'register/index/',
'gd'=>'Gd/index',
'public'=>'public/$1',
'^$'=>'site/index'
);
