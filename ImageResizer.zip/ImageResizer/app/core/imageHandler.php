<?php

class ImageHandler {
  private $fileImage;
  private $width;
  private $height;
  private $widthOrig;
  private $heightOrig;
  private $path;
  private $ratio;
  private $func;

  public function __construct($fileImage,$width,$height,$path) {
    $this->fileImage = $fileImage;
    $this->width = $width;
    $this->height = $height;
    $this->path = $path;
    $info=getimagesize($this->fileImage);
    list($this->widthOrig,$this->heightOrig)=$info;
    $this->ratio = $this->widthOrig/$this->heightOrig;
    $mime=explode('/',$info['mime'])[1];
    $this->func='imagecreatefrom'.$mime;
  }

  public function getInfo() {
    $imageinfo['ratio']=$this->ratio;
    $imageinfo['width']=$this->width;
    $imageinfo['height']=$this->height;
    $imageinfo['path']=$this->path;
    $imageinfo['func']=$this->func;
    $imageinfo['metrics']=implode(",",$this->calcRatio());
    return $imageinfo;
  }

 public function getImage(){
   $this->resize();
   return $this->path;
 }


 private function resize() {
    $image = imagecreatetruecolor($this->width,$this->height);
    $metrics=$this->calcRatio();
    $handler=$this->func;
    $resImage = $handler($this->fileImage);
    list($a,$b,$c,$d,$width,$height)=$metrics;
    imagecopyresampled($image,$resImage,$a,$b,$c,$d,$width,$height,
    $this->widthOrig,$this->heightOrig);
    $this->path=$this->path.'/img_v2.jpeg';
    imagejpeg($image,$this->path);
  }

 private function calcRatio() {
    if ($this->width/$this->height > $this->ratio) {
      $width=$this->height*$this->ratio;
      return array((($this->width-$width)/2),0,0,0,$width,$this->height);
    }
    else if($this->width/$this->height < $this->ratio) {
      $height=$this->width/$this->ratio;
      return array(0,(($this->height-$height)/2),0,0,$this->width,$height);
    }
    else {
      return array(0,0,0,0,$this->width,$this->height);
    }
  }

}
