<?php
 include './vendor/autoload.php';

 $loader = new Twig_Loader_Filesystem('./views/');
 $twig = new Twig_Environment($loader);

 $template = $twig->loadTemplate('main.tpl');
 echo $template->render(array('post' => $_POST));
 
?>
